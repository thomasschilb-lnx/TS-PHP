<!-- Guestbook v0.1 PM (thomas.schilb@live.de) -->
<?php
$mysql_host = "localhost";
$mysql_username = "";
$mysql_password = "";
$mysql_database = "";
?>