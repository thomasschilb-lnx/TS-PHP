<?php 
include "cronjob.ycombinator.php";
echo "<p>&nbsp;</p>";
echo "<p>&nbsp;</p>";
include "cronjob.heise.php";
echo "<p>&nbsp;</p>";
echo "<p>&nbsp;</p>";
include "cronjob.golem.php";
?>
