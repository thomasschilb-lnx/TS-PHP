INSERT INTO `since_forum_main` (`id`, `name`, `lastposter`, `lastpostdate`, `topics`, `replies`) VALUES
('1', 'News', '', '', '0', '0'),
('2', 'Links', '', '', '0', '0'),
('3', 'Software', '', '', '0', '0'),
('4', 'Games', '', '', '0', '0'),
('5', 'Tutorials', '', '', '0', '0'),
('6', 'Forum', '', '', '0', '0'),
('7', 'Stats', '', '', '0', '0'),
('8', 'Me', '', '', '0', '0'),
('9', 'Disclaimer', '', '', '0', '0');