<!-- since forum v0.2 (thomas.schilb@live.de) -->
<?php
mysql_connect('localhost','username','password');
mysql_select_db('databasename');
?>